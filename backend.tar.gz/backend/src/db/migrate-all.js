require('dotenv').config({ path: require('path').join(__dirname, '../../.env'), override: true });
const pool = require('./pool');

const MIGRATIONS = [
  {
    name: 'Add avatar_original_url to users',
    sql: `ALTER TABLE users ADD COLUMN IF NOT EXISTS avatar_original_url TEXT;`
  },
  {
    name: 'Add time column to scheduled_workouts',
    sql: `ALTER TABLE scheduled_workouts ADD COLUMN IF NOT EXISTS time VARCHAR(5);`
  },
  {
    name: 'Create water_intake table',
    sql: `
      CREATE TABLE IF NOT EXISTS water_intake (
        id SERIAL PRIMARY KEY,
        user_id UUID REFERENCES users(id) ON DELETE CASCADE,
        date DATE NOT NULL,
        glasses INTEGER NOT NULL DEFAULT 0,
        target_ml INTEGER NOT NULL DEFAULT 2000,
        updated_at TIMESTAMPTZ DEFAULT now(),
        UNIQUE (user_id, date)
      );
      CREATE INDEX IF NOT EXISTS idx_water_intake_user_date ON water_intake(user_id, date);
    `
  }
];

async function main() {
  console.log('Running all migrations...\n');
  for (const m of MIGRATIONS) {
    try {
      await pool.query(m.sql);
      console.log('  ✓ ' + m.name);
    } catch (err) {
      console.error('  ✗ ' + m.name + ': ' + err.message);
    }
  }
  console.log('\nAll migrations complete.');
  await pool.end();
}

main().catch(err => { console.error(err); process.exit(1); });
