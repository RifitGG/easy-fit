require('dotenv').config({ path: require('path').join(__dirname, '../../.env'), override: true });
const pool = require('./pool');

async function main() {
  console.log('Adding time column...');
  await pool.query('ALTER TABLE scheduled_workouts ADD COLUMN IF NOT EXISTS time VARCHAR(5)');
  console.log('Done! Column added.');
  await pool.end();
}

main().catch(err => { console.error(err.message); process.exit(1); });
