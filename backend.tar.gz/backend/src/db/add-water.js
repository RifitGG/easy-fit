require('dotenv').config({ path: require('path').join(__dirname, '../../.env'), override: true });
const pool = require('./pool');

const SQL = `
CREATE TABLE IF NOT EXISTS water_intake (
  id SERIAL PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  glasses INTEGER NOT NULL DEFAULT 0,
  target_ml INTEGER NOT NULL DEFAULT 2000,
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE (user_id, date)
);

CREATE INDEX IF NOT EXISTS idx_water_intake_user_date ON water_intake(user_id, date);
`;

async function main() {
  console.log('Adding water_intake table...');
  await pool.query(SQL);
  console.log('Done.');
  await pool.end();
}

main().catch(err => { console.error(err); process.exit(1); });
