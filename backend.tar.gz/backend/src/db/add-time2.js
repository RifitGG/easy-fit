require('dotenv').config({ path: require('path').join(__dirname, '../../.env'), override: true });
const { Pool } = require('pg');

// Connect to a different DB (postgres) to terminate fitapp connections
const adminPool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '4000'),
  database: 'postgres',
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || '1',
});

async function main() {
  console.log('Terminating all connections to fitapp...');
  const res = await adminPool.query(
    "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = 'fitapp'"
  );
  console.log('Terminated', res.rowCount, 'connections');
  await adminPool.end();

  // Now connect to fitapp and alter
  const pool = new Pool({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '4000'),
    database: 'fitapp',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || '1',
  });

  console.log('Adding time column...');
  await pool.query('ALTER TABLE scheduled_workouts ADD COLUMN IF NOT EXISTS time VARCHAR(5)');
  console.log('Done! Column added.');
  await pool.end();
}

main().catch(err => { console.error(err.message); process.exit(1); });
