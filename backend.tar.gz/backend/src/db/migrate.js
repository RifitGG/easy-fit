require('dotenv').config({ path: require('path').join(__dirname, '../../.env'), override: true });
const pool = require('./pool');

async function main() {
  // Terminate other connections
  await pool.query(
    "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='fitapp' AND pid <> pg_backend_pid()"
  );
  console.log('Terminated other connections');

  // Now run create.js SQL
  const createModule = require('fs').readFileSync(require('path').join(__dirname, 'create.js'), 'utf8');
  const sqlMatch = createModule.match(/const SQL = `([\s\S]*?)`;/);
  if (!sqlMatch) { console.error('Could not extract SQL'); process.exit(1); }
  
  console.log('Running schema...');
  await pool.query(sqlMatch[1]);
  console.log('Schema created successfully.');
  await pool.end();
}

main().catch(err => { console.error(err); process.exit(1); });
