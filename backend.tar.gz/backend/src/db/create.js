require('dotenv').config({ path: require('path').join(__dirname, '../../.env'), override: true });
const pool = require('./pool');

const SQL = `
DROP TABLE IF EXISTS published_workout_likes CASCADE;
DROP TABLE IF EXISTS published_workouts CASCADE;
DROP TABLE IF EXISTS completed_sets CASCADE;
DROP TABLE IF EXISTS workout_log_exercises CASCADE;
DROP TABLE IF EXISTS workout_logs CASCADE;
DROP TABLE IF EXISTS workout_exercises CASCADE;
DROP TABLE IF EXISTS workouts CASCADE;
DROP TABLE IF EXISTS scheduled_workouts CASCADE;
DROP TABLE IF EXISTS exercise_steps CASCADE;
DROP TABLE IF EXISTS exercise_muscles CASCADE;
DROP TABLE IF EXISTS exercises CASCADE;
DROP TABLE IF EXISTS users CASCADE;

DROP TYPE IF EXISTS equipment_type CASCADE;
DROP TYPE IF EXISTS difficulty_level CASCADE;
DROP TYPE IF EXISTS muscle_group CASCADE;

CREATE TYPE equipment_type AS ENUM (
  'barbell','dumbbell','cable','machine','bodyweight','kettlebell','bands'
);
CREATE TYPE difficulty_level AS ENUM (
  'beginner','intermediate','advanced'
);
CREATE TYPE muscle_group AS ENUM (
  'chest','back','shoulders','biceps','triceps','legs','glutes','abs','forearms','calves'
);

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(100) NOT NULL,
  avatar_url TEXT,
  avatar_original_url TEXT,
  height_cm INTEGER,
  weight_kg REAL,
  birth_date DATE,
  goal VARCHAR(100),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE exercises (
  id VARCHAR(64) PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  equipment equipment_type,
  difficulty difficulty_level,
  description TEXT
);

CREATE TABLE exercise_muscles (
  exercise_id VARCHAR(64) REFERENCES exercises(id) ON DELETE CASCADE,
  muscle_group muscle_group,
  PRIMARY KEY (exercise_id, muscle_group)
);

CREATE TABLE exercise_steps (
  id SERIAL PRIMARY KEY,
  exercise_id VARCHAR(64) REFERENCES exercises(id) ON DELETE CASCADE,
  step_order INTEGER NOT NULL,
  text TEXT NOT NULL
);

CREATE TABLE workouts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  name VARCHAR(200) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE workout_exercises (
  id SERIAL PRIMARY KEY,
  workout_id UUID REFERENCES workouts(id) ON DELETE CASCADE,
  exercise_id VARCHAR(64) REFERENCES exercises(id) ON DELETE SET NULL,
  exercise_order INTEGER NOT NULL,
  sets INTEGER DEFAULT 3,
  reps INTEGER DEFAULT 10,
  rest_seconds INTEGER DEFAULT 60
);

CREATE TABLE scheduled_workouts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  workout_id UUID REFERENCES workouts(id) ON DELETE CASCADE,
  workout_name VARCHAR(200),
  date DATE NOT NULL,
  time VARCHAR(5)
);

CREATE TABLE workout_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  workout_id UUID REFERENCES workouts(id) ON DELETE SET NULL,
  workout_name VARCHAR(200),
  date DATE NOT NULL,
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  duration_minutes INTEGER
);

CREATE TABLE workout_log_exercises (
  id SERIAL PRIMARY KEY,
  log_id UUID REFERENCES workout_logs(id) ON DELETE CASCADE,
  exercise_id VARCHAR(64) REFERENCES exercises(id) ON DELETE SET NULL,
  target_sets INTEGER,
  target_reps INTEGER,
  rest_seconds INTEGER
);

CREATE TABLE completed_sets (
  id SERIAL PRIMARY KEY,
  log_exercise_id INTEGER REFERENCES workout_log_exercises(id) ON DELETE CASCADE,
  set_order INTEGER NOT NULL,
  reps INTEGER,
  completed BOOLEAN DEFAULT false
);

CREATE INDEX idx_workouts_user ON workouts(user_id);
CREATE INDEX idx_workout_logs_user ON workout_logs(user_id);
CREATE INDEX idx_workout_logs_date ON workout_logs(date);
CREATE INDEX idx_scheduled_user ON scheduled_workouts(user_id);
CREATE INDEX idx_exercise_muscles_group ON exercise_muscles(muscle_group);

CREATE TABLE published_workouts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workout_id UUID REFERENCES workouts(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(200) NOT NULL,
  description TEXT DEFAULT '',
  difficulty difficulty_level DEFAULT 'intermediate',
  views INTEGER DEFAULT 0,
  likes_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE published_workout_likes (
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  published_id UUID REFERENCES published_workouts(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  PRIMARY KEY (user_id, published_id)
);

CREATE INDEX idx_published_user ON published_workouts(user_id);
CREATE INDEX idx_published_created ON published_workouts(created_at DESC);
CREATE INDEX idx_published_likes ON published_workouts(likes_count DESC);
`;

async function main() {
  console.log('Creating database schema...');
  await pool.query(SQL);
  console.log('Schema created successfully.');
  await pool.end();
}

main().catch(err => { console.error(err); process.exit(1); });
